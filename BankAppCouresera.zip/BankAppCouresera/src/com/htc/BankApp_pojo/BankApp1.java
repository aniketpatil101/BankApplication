package com.htc.BankApp_pojo;

public class BankApp1 {
public static void main(String[] args) {
	System.out.println("Bank Admin Menu");

}
}
